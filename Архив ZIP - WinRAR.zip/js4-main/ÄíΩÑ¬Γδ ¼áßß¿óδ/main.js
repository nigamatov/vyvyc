
let arr = ['Привет, ', 'мир', '!'];
let phrase = arr.join('');
console.log(phrase);
let arr = ['Привет, ', 'мир', '!'];
let text = arr.join('');
console.log(text);


let arr = ['Привет, ', 'мир', '!'];
arr[0] = 'Пока, ';
console.log(arr.join(''));


let salaries = {
    'Петя': 300,
    'Коля': 400,
    'Даша': 250
  };
  console.log('Зарплата Пети: ' + salaries['Петя']);
  console.log('Зарплата Коли: ' + salaries['Коля']);



let salaries = {
    'Joh': 100,
    'Jan': 200,
    'Jen': 300
  };
  
  console.log(salaries);
  console.log('Зарплата Joh: ' + salaries['Joh']);


var arr = {
    'ru':['голубой', 'красный', 'зелёный']
    'en':['blue', 'red', 'green']
};
console.log(arr['ru'][1]);
console.log(arr['en'][1]);



let arr = ['a', 'b', 'c'];
alert(arr.join(', ')); 



let arr = ['a', 'b', 'c'];

alert('Первый элемент: ' + arr[0]);
alert('Второй элемент: ' + arr[1]);
alert('Третий элемент: ' + arr[2]);



let arr = ['a', 'b', 'c', 'd'];
let result = arr[0] + '+' + arr[1] + ', ' + arr[2] + '+' + arr[3];

console.log(result);
alert(result);


let arr = [2, 5, 3, 9];
let result = arr[0] * arr[1] + arr[2] * arr[3];

console.log(result); 


let obj = {
    'a': 1,
    'b': 2,
    'c': 3
  };
  console.log(obj['c']); 
  console.log(obj.c); 


  var obj = {Коля: '1000', Вася: '500', Петя: '200’};
var obj = {
    Коля: '1000',
    Вася: '500',
    Петя: '200'
  };
  console.log('Зарплата Пети: ' + obj.Петя); 
  console.log('Зарплата Коли: ' + obj.Коля); 


  let daysOfWeek = {
    0: 'Воскресенье',
    1: 'Понедельник',
    2: 'Вторник',
    3: 'Среда',
    4: 'Четверг',
    5: 'Пятница',
    6: 'Суббота'
  };
  
  let currentDay = new Date().getDay();
  
  console.log('Сегодня: ' + daysOfWeek[currentDay]);


  let day = 3;

let daysOfWeek = {
  0: 'Воскресенье',
  1: 'Понедельник',
  2: 'Вторник',
  3: 'Среда',
  4: 'Четверг',
  5: 'Пятница',
  6: 'Суббота'
};

console.log('День недели: ' + daysOfWeek[day]);
let arr = [ [1, 2, 3], [4, 5, 6], [7, 8, 9] ];

console.log(arr[1][0]);


let obj = {
    js: ['jQuery', 'Angular'],
    php: 'hello',
    css: 'world'
  };
  
  console.log(obj.js[0]); 


  let weekDays = {
    'ru': ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'],
    'en': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
  };
  console.log(weekDays['ru'][0]); 
  console.log(weekDays['en'][2]);

  let weekDays = {
    'ru': ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'],
    'en': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
  };
  
  let lang = 'ru';
  let day = 3; 
  
  console.log(weekDays[lang][day - 1]); 


